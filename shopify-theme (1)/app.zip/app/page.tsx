"use client"

import  from "../assets/product-form"

export default function SyntheticV0PageForDeployment() {
  return < />
}